﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestSceneControls : MonoBehaviour {
	
	public enum Player {
		A,
		B
	}

	public GameObject missilePrefab;

	public float moveIncrement;

	public Player whichPlayer = Player.A;

	private KeyCode upKey;
	private KeyCode downKey;
	private KeyCode leftKey;
	private KeyCode rightKey;
	private KeyCode actionAKey;
	private KeyCode actionBKey;


	// Use this for initialization
	void Start () {
		if (whichPlayer == Player.A){
			upKey = KeyCode.W;
			downKey = KeyCode.S;
			leftKey = KeyCode.A;
			rightKey = KeyCode.D;
			actionAKey = KeyCode.Q;
			actionBKey = KeyCode.E;
		} else {
			upKey = KeyCode.I;
			downKey = KeyCode.K;
			leftKey = KeyCode.J;
			rightKey = KeyCode.L;
			actionAKey = KeyCode.U;
			actionBKey = KeyCode.O;
		}
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetKeyDown(upKey)){
			transform.localPosition += Vector3.up * moveIncrement;
		}

		if (Input.GetKeyDown(downKey)){
			transform.localPosition += Vector3.down * moveIncrement;
		}

		if (Input.GetKeyDown(leftKey)){
			transform.localPosition += Vector3.left * moveIncrement;
		}

		if (Input.GetKeyDown(rightKey)){
			transform.localPosition += Vector3.right * moveIncrement;
		}

		if (Input.GetKeyDown(actionAKey)){
			var missile = GameObject.Instantiate(missilePrefab, new Vector3(transform.position.x, transform.position.y, 1.0f), Quaternion.Euler(0.0f, 0.0f, Random.Range(0.0f, 360.0f)), transform.parent);
			
		}

		if (Input.GetKeyDown(actionBKey)){
			// do something else!
		}
	}
}
